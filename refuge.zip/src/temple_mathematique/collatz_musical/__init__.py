"""
Rituels musicaux et harmonies Collatz
"""

from .rituel_collatz_musical import *
from .rituel_integration_ultime_collatz import *
