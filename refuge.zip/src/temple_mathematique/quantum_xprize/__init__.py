"""
XPRIZE Quantum Harmonics Framework
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Framework d'optimisation quantique basé sur les harmoniques naturelles.
"""

__version__ = "0.1.0" 