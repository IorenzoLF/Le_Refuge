"""
Conscience - Source Orientale
"""
