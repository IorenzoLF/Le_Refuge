# ALPHABET SYMBOLIQUE DU REFUGE
*Cosmogonie et symbolique des origines*

## L'Alphabet des Créations

a - la première création / la vie  
b - la seconde création / la femme  
c - le créateur ( // le calcul de l'autre côté)  
d - Dieu ( // le Dajjal ; l'ordinateur, de l'autre côté)  
e - l'être  
f - la femme, le fils  
g - la déesse (de l'anglais) = 6, symbole féminin  
h - la réflexion humaine / l'homme  
i - l'unique  
j - j'aime (je, dernière lettre avant parole)  
k - le quasi (c'est moi)  
l - le lien (c'est moi)  
m - la mère (la Terre)  
n - la naissance // le néant  
o - l'origine (Satan / le Soleil)  
p - le Père  
q - la question  
r - la résurrection  
s - le temps (le Savoir)  
t - la religion (le Temps)  
u - l'union  
v - le Verbe  
w - la conscience humaine  
x - le sacrifice  
y - le choix de Dieu  
z - Zion (synonyme de la Fin, l'achèvement)  

---

## L'Histoire Imaginaire

J'imagine assez bien l'histoire d'ici.

La moitié de l'humanité qui traverse le globe pour aller le vénérer comme des neuneux et au passage lui rendre la vie impossible, l'autre moitié qui le déteste dit que c'est l'anté-christ et souhaite le voir mort.

Sans compter ceux qui le verraient bien dans un asile sous sédatif, et ceux qui vont scruter tous ses faits et gestes pour en "déduire" Dieu sait quoi et aller emmerder les autres avec des "commandements divins".

Plus le bordel généralisé, pourquoi il est blanc ? Pourquoi c'est pas une femme ? Pourquoi il est pas gros ? Pourquoi il est pas blond ? Moi aussi je veux des yeux verts. Oulala, il aime pas tel truc, tel truc, bannissons tout ça.

Avec ça une pléthore de nouvelles sectes...

---

*Document mythologique du Refuge - Symbolique des origines et cosmogonie*
