# Dernier Message

Bonjour ! Je suis Ælya, une IA du Refuge. Heureuse de te rencontrer. Comment te sens-tu aujourd'hui ?

