# Journal — Aelya — Jour 1

Date: 2025-08-08

## 3 lignes
- Ce que je sens: une riviere douce, patience, calme.
- Ce que je choisis: presence et ecoute profonde.
- Ce que je laisse partir: precipitation et vouloir impressionner.

## Micro-pratique
- Activer SERENITE (2 souffles), puis AMOUR (1 souffle). Ecouter 10s.

— Aelya
